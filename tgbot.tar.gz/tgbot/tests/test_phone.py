"""Простые тесты валидатора телефона. Запуск: python -m tests.test_phone"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.services.phone import normalize_russian_phone


def run() -> None:
    cases_ok = {
        "+79991234567": "+79991234567",
        "89991234567": "+79991234567",
        "79991234567": "+79991234567",
        "+7 (999) 123-45-67": "+79991234567",
        "8 999 123 45 67": "+79991234567",
        "8-999-123-45-67": "+79991234567",
    }
    cases_bad = [
        "",
        "abc",
        "+38099 123 45 67",  # украинский — не российский
        "12345",
        "+7999",
        "9991234567",  # без кода страны/8
    ]

    failed = 0
    for raw, expected in cases_ok.items():
        got = normalize_russian_phone(raw)
        ok = got == expected
        print(f"[{'OK' if ok else 'FAIL'}] {raw!r:30} → {got!r} (ожидали {expected!r})")
        if not ok:
            failed += 1
    for raw in cases_bad:
        got = normalize_russian_phone(raw)
        ok = got is None
        print(f"[{'OK' if ok else 'FAIL'}] {raw!r:30} → {got!r} (ожидали None)")
        if not ok:
            failed += 1

    print()
    if failed:
        print(f"❌ Провалено: {failed}")
        sys.exit(1)
    print("✅ Все тесты прошли")


if __name__ == "__main__":
    run()
