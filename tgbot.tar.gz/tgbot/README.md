# Telegram-бот: квиз-воронка (порт сценария из Senler)

Перенос сценария «Сколько по времени и стоимости» из Senler на Python + aiogram 3 + PostgreSQL.

## Логика опроса

```
/start
  └─ SP-1  Длительность стресса: 1-2 / 3-6 / 6+ мес        → skolko_dlitsa_stress
     └─ ⏱ 5 мин
        └─ SP-2  Медитация (видео + Да/Нет)                 → hochet_meditasiy
           └─ ⏱ 5 мин
              └─ SP-3  Размер долга: 300-600к / 600к-1м / 1м+ → dolg
                 └─ ⏱ 5 мин
                    └─ SP-5  Готовность 1-3 / 4-7 / 8-10    → gor_hol
                       └─ ⏱ 1 час
                          └─ SP-7  Запрос телефона + валидация → nomer
                             └─ Отправка лида в админ-чат + статус completed
```

Если юзер не отвечает на шаге — через 5 мин (или 1 час на шаге телефона) уходит мягкий «дожим». Таймеры хранятся в PostgreSQL через APScheduler, поэтому переживают рестарт процесса.

## Структура проекта

```
tgbot/
├── main.py                       # точка входа
├── app/
│   ├── config.py                 # загрузка .env
│   ├── states.py                 # FSM-состояния
│   ├── texts.py                  # все тексты с плейсхолдерами
│   ├── db/
│   │   ├── engine.py             # async-движок SQLAlchemy
│   │   ├── models.py             # модель Lead
│   │   └── repo.py               # CRUD над лидами
│   ├── services/
│   │   ├── bot_ctx.py            # глобальный доступ к Bot для jobs
│   │   ├── keyboards.py          # inline / reply клавиатуры
│   │   ├── notifier.py           # отправка в админ-чат + CSV-экспорт
│   │   ├── phone.py              # валидация номера
│   │   └── scheduler.py          # APScheduler + PG jobstore
│   └── handlers/
│       └── quiz.py               # вся логика квиза
├── tests/test_phone.py           # тесты валидатора
├── requirements.txt
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── tgbot.service                 # для запуска без Docker
└── README.md
```

## Быстрый старт через Docker (рекомендую)

1. Получи токен у [@BotFather](https://t.me/BotFather).
2. Узнай ID админ-чата:
   - Создай группу, добавь туда бота
   - Отправь любое сообщение
   - Открой `https://api.telegram.org/bot<TOKEN>/getUpdates`
   - Скопируй `chat.id` (для групп начинается с `-100…`)
3. Узнай свой Telegram user_id у [@userinfobot](https://t.me/userinfobot).
4. На сервере:

```bash
git clone <repo> tgbot && cd tgbot
cp .env.example .env
# отредактируй .env: BOT_TOKEN, ADMIN_CHAT_ID, ADMIN_USER_IDS
docker compose up -d --build
docker compose logs -f bot
```

Готово — пиши боту `/start`.

## Запуск без Docker (Ubuntu/Debian)

```bash
# 1. Установить Python и Postgres
sudo apt update
sudo apt install -y python3 python3-venv python3-pip postgresql

# 2. Создать БД
sudo -u postgres psql <<EOF
CREATE USER botuser WITH PASSWORD 'botpass';
CREATE DATABASE tgbot OWNER botuser;
EOF

# 3. Развернуть код
mkdir -p ~/tgbot && cd ~/tgbot
# скопируй сюда содержимое проекта

python3 -m venv .venv
.venv/bin/pip install -r requirements.txt

cp .env.example .env
# заполни .env (DATABASE_URL для локального Postgres:
#   postgresql+asyncpg://botuser:botpass@localhost:5432/tgbot)

# 4. Проверочный запуск
.venv/bin/python -m main
```

Если всё ок — поднимаем как systemd-сервис:

```bash
sudo cp tgbot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now tgbot
sudo systemctl status tgbot
journalctl -u tgbot -f
```

## Команды бота

| Команда   | Кто видит | Что делает |
|-----------|-----------|------------|
| `/start`  | Все       | Запустить опрос (или перезапустить) |
| `/help`   | Все       | Список команд |
| `/reset`  | Все       | Сбросить текущий прогресс |
| `/export` | Только админы из `ADMIN_USER_IDS` | Прислать CSV со всеми лидами |

## Что заполнить перед запуском

1. **Тексты в `app/texts.py`** — на скринах Senler часть текстов была обрезана (`«Ка...»`, `«МА...»`). Места, где надо дописать, помечены `[ДОПОЛНИТЬ ТЕКСТ]`.

2. **Видео медитации (опционально)** — в `texts.py` есть `MEDITATION_VIDEO_FILE_ID`. Чтобы прикрепить видео:
   - Загрузи видео через `bot.send_video` в тестовом чате
   - В логах или через `getUpdates` найди `file_id`
   - Подставь его в `texts.py`

3. **Длительности таймеров** — по умолчанию как в Senler (5 мин / 1 час). Для теста удобно поставить в `.env`:
   ```
   TIMER_SHORT_SEC=30
   TIMER_LONG_SEC=60
   ```

## Тесты

```bash
python tests/test_phone.py
```

## Расширения, если понадобятся

- **Полноценная миграция БД** — `alembic init`, схема уже совместима
- **Несколько воронок** — в `texts.py` хранить структуру вопросов как dict, в БД добавить `funnel_id`
- **Интеграция с CRM/Google Sheets** — в `notifier.py` рядом с `notify_admin` добавить вызов webhook
- **A/B-тесты** — в `Lead` добавить колонку `variant`, в хендлерах рандомить тексты
- **Redis для FSM** — заменить `MemoryStorage` на `RedisStorage` (FSM-состояния тогда тоже переживут рестарт)
