"""FSM-состояния квиза."""

from aiogram.fsm.state import State, StatesGroup


class Quiz(StatesGroup):
    # Каждое состояние = ожидание ответа на соответствующий вопрос
    waiting_duration = State()      # Сколько длится стресс
    waiting_meditation = State()    # Хочет ли медитацию
    waiting_debt = State()          # Размер долга
    waiting_readiness = State()     # Готовность 1-10
    waiting_phone = State()         # Номер телефона
    done = State()                  # Опрос завершён
