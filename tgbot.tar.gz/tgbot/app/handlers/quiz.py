"""
Хендлеры квиза.

Граф из Senler:
    /start → SP-1 (длительность стресса) → таймер 5 мин →
    SP-2 (медитация Да/Нет) → таймер 5 мин →
    SP-3 (размер долга) → таймер 5 мин →
    SP-5 (готовность 1-10) → таймер 1 час →
    SP-7 (номер телефона) → валидация → завершение + отправка админу

Между шагами:
  * сохранение ответа в БД
  * планирование дожима (если юзер не ответил)
  * предыдущий дожим отменяется при ответе
"""

import logging

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Contact, Message

from app import texts
from app.config import Config
from app.db import repo
from app.services import notifier
from app.services.keyboards import options_kb, phone_request_kb, remove_kb
from app.services.phone import normalize_russian_phone
from app.services.scheduler import cancel_nudge, nudge_job_id, schedule_nudge
from app.states import Quiz

log = logging.getLogger(__name__)
router = Router()


# ----- helpers -----

def _username(message_or_cb: Message | CallbackQuery) -> str:
    user = message_or_cb.from_user
    if user is None:
        return "друг"
    return user.first_name or user.username or "друг"


async def _save_lead_field(state: FSMContext, field: str, value: str) -> None:
    data = await state.get_data()
    lead_id = data.get("lead_id")
    if lead_id:
        await repo.update_lead_field(lead_id, field, value)


def _plan_nudge(cfg: Config, user_id: int, step: str, *, long: bool = False) -> None:
    delay = cfg.timer_long_sec if long else cfg.timer_short_sec
    schedule_nudge(
        job_id=nudge_job_id(user_id, step),
        delay_sec=delay,
        func_path="app.handlers.quiz:run_nudge",
        user_id=user_id,
        step=step,
    )


def _cancel_nudge_for(user_id: int, step: str) -> None:
    cancel_nudge(nudge_job_id(user_id, step))


async def _remove_inline_kb(message: Message) -> None:
    """Снять inline-кнопки у сообщения, не падая, если уже снято."""
    try:
        await message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass


# ----- /start: SP-1 -----

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, cfg: Config) -> None:
    user = message.from_user
    if user is None:
        return

    await state.clear()
    for step in ("duration", "meditation", "debt", "readiness", "phone"):
        _cancel_nudge_for(user.id, step)

    lead = await repo.get_or_create_lead(
        tg_user_id=user.id,
        username=user.username,
        full_name=user.full_name,
    )
    await state.update_data(lead_id=lead.id)
    await state.set_state(Quiz.waiting_duration)

    await message.answer(
        texts.Q_DURATION.format(username=_username(message)),
        reply_markup=options_kb(texts.DURATION_OPTIONS, prefix="dur"),
    )
    _plan_nudge(cfg, user.id, step="duration")


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    await message.answer(texts.HELP_TEXT)


@router.message(Command("reset"))
async def cmd_reset(message: Message, state: FSMContext) -> None:
    if message.from_user is None:
        return
    await state.clear()
    await repo.reset_lead(message.from_user.id)
    for step in ("duration", "meditation", "debt", "readiness", "phone"):
        _cancel_nudge_for(message.from_user.id, step)
    await message.answer(texts.RESET_TEXT, reply_markup=remove_kb())


# ----- SP-1 → SP-2 -----

@router.callback_query(Quiz.waiting_duration, F.data.startswith("dur:"))
async def on_duration(cb: CallbackQuery, state: FSMContext, cfg: Config) -> None:
    if cb.data is None or cb.from_user is None or not isinstance(cb.message, Message):
        return
    value = cb.data.split(":", 1)[1]

    await _save_lead_field(state, "skolko_dlitsa_stress", value)
    _cancel_nudge_for(cb.from_user.id, "duration")
    await cb.answer()
    await _remove_inline_kb(cb.message)

    await state.set_state(Quiz.waiting_meditation)
    kb = options_kb(texts.MEDITATION_OPTIONS, prefix="med")
    if texts.MEDITATION_VIDEO_FILE_ID:
        await cb.bot.send_video(
            chat_id=cb.from_user.id,
            video=texts.MEDITATION_VIDEO_FILE_ID,
            caption=texts.Q_MEDITATION,
            reply_markup=kb,
        )
    else:
        await cb.bot.send_message(
            chat_id=cb.from_user.id, text=texts.Q_MEDITATION, reply_markup=kb
        )
    _plan_nudge(cfg, cb.from_user.id, step="meditation")


# ----- SP-2 → SP-3 -----

@router.callback_query(Quiz.waiting_meditation, F.data.startswith("med:"))
async def on_meditation(cb: CallbackQuery, state: FSMContext, cfg: Config) -> None:
    if cb.data is None or cb.from_user is None or not isinstance(cb.message, Message):
        return
    value = cb.data.split(":", 1)[1]

    await _save_lead_field(state, "hochet_meditasiy", value)
    _cancel_nudge_for(cb.from_user.id, "meditation")
    await cb.answer()
    await _remove_inline_kb(cb.message)

    await state.set_state(Quiz.waiting_debt)
    await cb.bot.send_message(
        chat_id=cb.from_user.id,
        text=texts.Q_DEBT,
        reply_markup=options_kb(texts.DEBT_OPTIONS, prefix="debt"),
    )
    _plan_nudge(cfg, cb.from_user.id, step="debt")


# ----- SP-3 → SP-5 -----

@router.callback_query(Quiz.waiting_debt, F.data.startswith("debt:"))
async def on_debt(cb: CallbackQuery, state: FSMContext, cfg: Config) -> None:
    if cb.data is None or cb.from_user is None or not isinstance(cb.message, Message):
        return
    value = cb.data.split(":", 1)[1]

    await _save_lead_field(state, "dolg", value)
    _cancel_nudge_for(cb.from_user.id, "debt")
    await cb.answer()
    await _remove_inline_kb(cb.message)

    await state.set_state(Quiz.waiting_readiness)
    await cb.bot.send_message(
        chat_id=cb.from_user.id,
        text=texts.Q_READINESS,
        reply_markup=options_kb(texts.READINESS_OPTIONS, prefix="rdy"),
    )
    _plan_nudge(cfg, cb.from_user.id, step="readiness")


# ----- SP-5 → SP-7 -----

@router.callback_query(Quiz.waiting_readiness, F.data.startswith("rdy:"))
async def on_readiness(cb: CallbackQuery, state: FSMContext, cfg: Config) -> None:
    if cb.data is None or cb.from_user is None or not isinstance(cb.message, Message):
        return
    value = cb.data.split(":", 1)[1]

    await _save_lead_field(state, "gor_hol", value)
    _cancel_nudge_for(cb.from_user.id, "readiness")
    await cb.answer()
    await _remove_inline_kb(cb.message)

    await state.set_state(Quiz.waiting_phone)
    await cb.bot.send_message(
        chat_id=cb.from_user.id,
        text=texts.Q_PHONE.format(username=_username(cb)),
        reply_markup=phone_request_kb(),
    )
    # Длинный таймер 1 час, как в Senler (SP-58)
    _plan_nudge(cfg, cb.from_user.id, step="phone", long=True)


# ----- SP-7: телефон -----

@router.message(Quiz.waiting_phone, F.contact)
async def on_phone_contact(message: Message, state: FSMContext, cfg: Config) -> None:
    contact: Contact | None = message.contact
    if contact is None or message.from_user is None:
        return

    if contact.user_id and contact.user_id != message.from_user.id:
        await message.answer(texts.PHONE_INVALID)
        return

    phone = normalize_russian_phone(contact.phone_number)
    if phone is None:
        await message.answer(texts.PHONE_INVALID)
        return
    await _finalize_phone(message, state, cfg, phone)


@router.message(Quiz.waiting_phone, F.text)
async def on_phone_text(message: Message, state: FSMContext, cfg: Config) -> None:
    if message.text is None or message.from_user is None:
        return
    phone = normalize_russian_phone(message.text)
    if phone is None:
        await message.answer(texts.PHONE_INVALID)
        return
    await _finalize_phone(message, state, cfg, phone)


async def _finalize_phone(
    message: Message, state: FSMContext, cfg: Config, phone: str
) -> None:
    user = message.from_user
    assert user is not None

    await _save_lead_field(state, "nomer", phone)
    _cancel_nudge_for(user.id, "phone")

    data = await state.get_data()
    lead_id = data.get("lead_id")
    if lead_id:
        lead = await repo.mark_completed(lead_id)
        if lead is not None:
            try:
                await notifier.notify_admin(message.bot, cfg.admin_chat_id, lead)
            except Exception:
                log.exception("Не удалось отправить лид в админ-чат")

    await state.set_state(Quiz.done)
    await message.answer(texts.FINAL_THANKS, reply_markup=remove_kb())


# ----- Фолбэк -----

@router.message(F.text)
async def fallback(message: Message, state: FSMContext) -> None:
    current = await state.get_state()
    if current is None:
        await message.answer(
            "Чтобы начать опрос, напишите /start. /help — все команды."
        )
    else:
        await message.answer("Пожалуйста, выберите вариант с помощью кнопок выше.")


# ----- Команда экспорта (только для админов) -----

@router.message(Command("export"))
async def cmd_export(message: Message, cfg: Config) -> None:
    if message.from_user is None or message.from_user.id not in cfg.admin_user_ids:
        return  # молча игнорируем для не-админов
    try:
        await notifier.export_leads_csv(message.bot, message.chat.id)
    except Exception:
        log.exception("Ошибка при экспорте CSV")
        await message.answer("Не удалось сформировать CSV. Смотри логи.")


# ----- Дожимы (job для APScheduler) -----

async def run_nudge(user_id: int, step: str) -> None:
    """Вызывается планировщиком. Шлёт мягкое напоминание, если юзер не ответил."""
    from sqlalchemy import select

    from app.db.engine import get_session_factory
    from app.db.models import Lead
    from app.services.bot_ctx import get_bot

    bot = get_bot()

    name = "друг"
    async with get_session_factory()() as session:
        stmt = (
            select(Lead)
            .where(Lead.tg_user_id == user_id)
            .order_by(Lead.created_at.desc())
            .limit(1)
        )
        lead = (await session.execute(stmt)).scalar_one_or_none()
        if lead is not None:
            # Не дёргаем, если опрос уже завершён
            if lead.status == "completed":
                return
            if lead.full_name:
                name = lead.full_name.split()[0]
            elif lead.username:
                name = lead.username

    nudge_text_map = {
        "duration": texts.NUDGE_AFTER_DURATION,
        "meditation": texts.NUDGE_AFTER_MEDITATION,
        "debt": texts.NUDGE_AFTER_MEDITATION,
        "readiness": texts.NUDGE_AFTER_MEDITATION,
        "phone": texts.NUDGE_AFTER_PHONE_PROMPT,
    }
    template = nudge_text_map.get(step)
    if template is None:
        return

    try:
        await bot.send_message(user_id, template.format(username=name))
    except Exception:
        log.warning("Не удалось отправить дожим юзеру %s на шаге %s", user_id, step)
