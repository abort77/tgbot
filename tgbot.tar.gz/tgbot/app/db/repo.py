"""Доступ к данным лидов."""

from sqlalchemy import select

from app.db.engine import get_session_factory
from app.db.models import Lead


async def get_or_create_lead(
    tg_user_id: int,
    username: str | None,
    full_name: str | None,
) -> Lead:
    """Найти активный лид пользователя или создать новый."""
    factory = get_session_factory()
    async with factory() as session:
        # Берём последнюю не-завершённую запись, иначе создаём новую
        stmt = (
            select(Lead)
            .where(Lead.tg_user_id == tg_user_id, Lead.status == "in_progress")
            .order_by(Lead.created_at.desc())
            .limit(1)
        )
        lead = (await session.execute(stmt)).scalar_one_or_none()

        if lead is None:
            lead = Lead(
                tg_user_id=tg_user_id,
                username=username,
                full_name=full_name,
            )
            session.add(lead)
            await session.commit()
            await session.refresh(lead)
        else:
            # Обновим имя/username, если изменилось
            changed = False
            if username and lead.username != username:
                lead.username = username
                changed = True
            if full_name and lead.full_name != full_name:
                lead.full_name = full_name
                changed = True
            if changed:
                await session.commit()
                await session.refresh(lead)

        return lead


async def update_lead_field(lead_id: int, field: str, value: str) -> None:
    """Обновить один ответ в анкете."""
    allowed = {"skolko_dlitsa_stress", "hochet_meditasiy", "dolg", "gor_hol", "nomer"}
    if field not in allowed:
        raise ValueError(f"Недопустимое поле: {field}")

    factory = get_session_factory()
    async with factory() as session:
        lead = await session.get(Lead, lead_id)
        if lead is None:
            return
        setattr(lead, field, value)
        await session.commit()


async def mark_completed(lead_id: int) -> Lead | None:
    """Пометить лид как завершённый и вернуть его (для отправки админам)."""
    factory = get_session_factory()
    async with factory() as session:
        lead = await session.get(Lead, lead_id)
        if lead is None:
            return None
        lead.status = "completed"
        await session.commit()
        await session.refresh(lead)
        return lead


async def reset_lead(tg_user_id: int) -> None:
    """Пометить активные лиды юзера как abandoned (для команды /reset)."""
    factory = get_session_factory()
    async with factory() as session:
        stmt = select(Lead).where(
            Lead.tg_user_id == tg_user_id, Lead.status == "in_progress"
        )
        for lead in (await session.execute(stmt)).scalars():
            lead.status = "abandoned"
        await session.commit()
