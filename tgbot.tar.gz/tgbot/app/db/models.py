"""SQLAlchemy-модели."""

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class Lead(Base):
    """Заявка от пользователя. Один пользователь = одна актуальная строка."""

    __tablename__ = "leads"

    id: Mapped[int] = mapped_column(primary_key=True)

    # Telegram-идентификаторы
    tg_user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Ответы квиза (в терминах Senler-переменных)
    skolko_dlitsa_stress: Mapped[str | None] = mapped_column(String(32), nullable=True)
    hochet_meditasiy: Mapped[str | None] = mapped_column(String(8), nullable=True)
    dolg: Mapped[str | None] = mapped_column(String(16), nullable=True)
    gor_hol: Mapped[str | None] = mapped_column(String(8), nullable=True)
    nomer: Mapped[str | None] = mapped_column(String(32), nullable=True)

    # Статус прохождения
    status: Mapped[str] = mapped_column(String(32), default="in_progress")
    # Возможные значения: in_progress, completed, abandoned

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
