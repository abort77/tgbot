"""Async-движок и фабрика сессий."""

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.db.models import Base

_engine = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def init_engine(database_url: str) -> None:
    """Инициализация движка. Вызывается один раз при старте."""
    global _engine, _session_factory
    _engine = create_async_engine(database_url, pool_pre_ping=True)
    _session_factory = async_sessionmaker(_engine, expire_on_commit=False)


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    if _session_factory is None:
        raise RuntimeError("DB не инициализирована: вызови init_engine() при старте")
    return _session_factory


async def create_all() -> None:
    """Создать таблицы (для прод-окружения лучше использовать Alembic)."""
    if _engine is None:
        raise RuntimeError("DB не инициализирована")
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def dispose() -> None:
    if _engine is not None:
        await _engine.dispose()
