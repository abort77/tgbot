"""Сборщики клавиатур."""

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)


def options_kb(options: list[tuple[str, str]], prefix: str) -> InlineKeyboardMarkup:
    """
    Inline-клавиатура из списка (label, value).
    callback_data = f"{prefix}:{value}"
    """
    rows = [
        [InlineKeyboardButton(text=label, callback_data=f"{prefix}:{value}")]
        for label, value in options
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def phone_request_kb() -> ReplyKeyboardMarkup:
    """Reply-кнопка «Отправить контакт» — самый надёжный способ получить номер."""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📱 Отправить мой номер", request_contact=True)]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def remove_kb() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()
