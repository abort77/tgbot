"""Уведомление админ-чата о новом лиде + CSV-выгрузка."""

import csv
import io
from datetime import datetime

from aiogram import Bot
from aiogram.types import BufferedInputFile
from sqlalchemy import select

from app.db.engine import get_session_factory
from app.db.models import Lead

# Человекочитаемые названия ответов
_LABELS = {
    "1-2_months": "1-2 месяца",
    "3-6_months": "3-6 месяцев",
    "6+_months": "от 6 и более месяцев",
    "yes": "Да",
    "no": "Нет",
    "300-600k": "300-600 тыс ₽",
    "600k-1m": "600 тыс - 1 млн ₽",
    "1m+": "более 1 млн ₽",
    "1-3": "1-3 (не готов)",
    "4-7": "4-7 (начинает шаги)",
    "8-10": "8-10 (готов)",
}


def _label(v: str | None) -> str:
    if v is None:
        return "—"
    return _LABELS.get(v, v)


def format_lead(lead: Lead) -> str:
    """Сформировать текст для админ-чата."""
    name = lead.full_name or "—"
    username = f"@{lead.username}" if lead.username else "—"
    return (
        "🔥 <b>Новый лид</b>\n\n"
        f"<b>Имя:</b> {name}\n"
        f"<b>Username:</b> {username}\n"
        f"<b>TG ID:</b> <code>{lead.tg_user_id}</code>\n"
        f"<b>Телефон:</b> <code>{lead.nomer or '—'}</code>\n\n"
        f"<b>Длительность стресса:</b> {_label(lead.skolko_dlitsa_stress)}\n"
        f"<b>Хочет медитацию:</b> {_label(lead.hochet_meditasiy)}\n"
        f"<b>Размер долга:</b> {_label(lead.dolg)}\n"
        f"<b>Готовность:</b> {_label(lead.gor_hol)}\n\n"
        f"<i>Создан: {lead.created_at:%Y-%m-%d %H:%M UTC}</i>"
    )


async def notify_admin(bot: Bot, admin_chat_id: int, lead: Lead) -> None:
    """Послать карточку лида в админ-чат."""
    await bot.send_message(admin_chat_id, format_lead(lead))


async def export_leads_csv(bot: Bot, chat_id: int) -> None:
    """Выгрузить всех лидов в CSV и отправить в чат (для /export)."""
    factory = get_session_factory()
    async with factory() as session:
        leads = (
            await session.execute(select(Lead).order_by(Lead.created_at.desc()))
        ).scalars().all()

    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow([
        "id", "created_at", "status",
        "tg_user_id", "username", "full_name", "phone",
        "duration", "wants_meditation", "debt", "readiness",
    ])
    for l in leads:
        writer.writerow([
            l.id,
            l.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            l.status,
            l.tg_user_id,
            l.username or "",
            l.full_name or "",
            l.nomer or "",
            _label(l.skolko_dlitsa_stress),
            _label(l.hochet_meditasiy),
            _label(l.dolg),
            _label(l.gor_hol),
        ])

    data = buf.getvalue().encode("utf-8-sig")  # BOM — чтобы Excel понимал кириллицу
    filename = f"leads_{datetime.utcnow():%Y%m%d_%H%M}.csv"
    await bot.send_document(
        chat_id,
        BufferedInputFile(data, filename=filename),
        caption=f"Выгрузка лидов: {len(leads)} шт.",
    )
