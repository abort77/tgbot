"""
Отложенные задания (таймеры из Senler).

Используем APScheduler с SQLAlchemyJobStore — задания хранятся в той же
PostgreSQL, поэтому переживают рестарт процесса.
"""

from datetime import datetime, timedelta, timezone

from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.asyncio import AsyncIOScheduler

_scheduler: AsyncIOScheduler | None = None


def _sync_db_url(async_url: str) -> str:
    """APScheduler требует sync-драйвер: postgresql+asyncpg -> postgresql+psycopg2."""
    if "+asyncpg" in async_url:
        return async_url.replace("+asyncpg", "+psycopg2")
    return async_url


def init_scheduler(database_url: str) -> AsyncIOScheduler:
    global _scheduler
    jobstore = SQLAlchemyJobStore(url=_sync_db_url(database_url))
    _scheduler = AsyncIOScheduler(
        jobstores={"default": jobstore},
        timezone="UTC",
    )
    return _scheduler


def get_scheduler() -> AsyncIOScheduler:
    if _scheduler is None:
        raise RuntimeError("Планировщик не инициализирован")
    return _scheduler


def schedule_nudge(
    job_id: str,
    delay_sec: int,
    func_path: str,           # "app.handlers.nudges:run_nudge"
    *,
    user_id: int,
    step: str,
) -> None:
    """Поставить дожим через delay_sec секунд (с заменой существующего)."""
    run_at = datetime.now(timezone.utc) + timedelta(seconds=delay_sec)
    get_scheduler().add_job(
        func=func_path,
        trigger="date",
        run_date=run_at,
        id=job_id,
        kwargs={"user_id": user_id, "step": step},
        replace_existing=True,
        misfire_grace_time=24 * 3600,  # если бот лежал — отправить при старте
    )


def cancel_nudge(job_id: str) -> None:
    try:
        get_scheduler().remove_job(job_id)
    except Exception:
        # Уже выполнено или не существует — ок
        pass


def nudge_job_id(user_id: int, step: str) -> str:
    return f"nudge:{user_id}:{step}"
