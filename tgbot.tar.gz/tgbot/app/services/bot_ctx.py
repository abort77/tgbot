"""Глобальный доступ к экземпляру Bot — нужен для отложенных jobs."""

from aiogram import Bot

_bot: Bot | None = None


def set_bot(bot: Bot) -> None:
    global _bot
    _bot = bot


def get_bot() -> Bot:
    if _bot is None:
        raise RuntimeError("Bot не инициализирован")
    return _bot
