#!/usr/bin/env bash
# deploy.sh — поднимает бота на чистом Ubuntu/Debian VPS.
# Запускать на сервере из распакованной папки tgbot/:
#   bash deploy.sh

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
say()  { echo -e "${GREEN}==>${NC} $*"; }
warn() { echo -e "${YELLOW}!!${NC} $*"; }
die()  { echo -e "${RED}xx${NC} $*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Запусти от root или через sudo: sudo bash deploy.sh"
[[ -f Dockerfile && -f docker-compose.yml ]] || die "Запусти из папки tgbot/"

# 1) Docker
if ! command -v docker >/dev/null 2>&1; then
  say "Ставлю Docker…"
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  . /etc/os-release
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/${ID} ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  systemctl enable --now docker
else
  say "Docker уже установлен"
fi

# 2) .env
if [[ -f .env ]]; then
  warn ".env уже существует — оставляю как есть"
else
  say "Сейчас спрошу секреты. Они НЕ попадут в историю команд."
  echo
  read -r -s -p "BOT_TOKEN от @BotFather (ввод скрыт): " BOT_TOKEN; echo
  [[ -n "$BOT_TOKEN" ]] || die "Токен пустой"

  read -r -p "ADMIN_CHAT_ID (id админ-чата, начинается с -100…): " ADMIN_CHAT_ID
  [[ -n "$ADMIN_CHAT_ID" ]] || die "ADMIN_CHAT_ID пустой"

  read -r -p "ADMIN_USER_IDS (твой user_id, можно несколько через запятую): " ADMIN_USER_IDS
  [[ -n "$ADMIN_USER_IDS" ]] || die "ADMIN_USER_IDS пустой"

  read -r -s -p "Пароль для PostgreSQL (придумай любой): " PG_PASSWORD; echo
  [[ -n "$PG_PASSWORD" ]] || die "Пароль пустой"

  umask 077
  cat > .env <<EOF
BOT_TOKEN=${BOT_TOKEN}
ADMIN_CHAT_ID=${ADMIN_CHAT_ID}
ADMIN_USER_IDS=${ADMIN_USER_IDS}
DATABASE_URL=postgresql+asyncpg://botuser:${PG_PASSWORD}@db:5432/tgbot
POSTGRES_PASSWORD=${PG_PASSWORD}
EOF
  chmod 600 .env
  say ".env создан с правами 600"
fi

# 3) docker-compose: используем пароль из .env
if ! grep -q 'POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}' docker-compose.yml; then
  say "Патчу docker-compose.yml, чтобы пароль брался из .env"
  sed -i 's/POSTGRES_PASSWORD: botpass/POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}/' docker-compose.yml
fi

# 4) Запуск
say "Собираю и поднимаю контейнеры…"
docker compose up -d --build

say "Готово. Логи:"
echo "  docker compose logs -f bot"
echo
say "Проверь бота: открой Telegram, напиши /start"
